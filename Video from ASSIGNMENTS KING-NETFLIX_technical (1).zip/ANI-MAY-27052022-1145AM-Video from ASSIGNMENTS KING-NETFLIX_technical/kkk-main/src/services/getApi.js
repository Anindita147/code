const BASE_URL = `https://api.themoviedb.org/3`;

const companies = {
    "Netflix": "8",
    "Crave": "230",
    "Disney": "337",
    "Apple Plus": "350"
}

const myApiKey = '02f5d3847dfcb55ed317924dc9b17d62';
export const getMovies = async () => {
    const popularMoviesUrl = `${BASE_URL}/discover/tv?api_key=${myApiKey}&with_watch_providers=`;
    const resultArr = [];

    for (let company in companies) {
        const response = fetch(`${popularMoviesUrl}${companies[company]}`);
        resultArr.push(response);
    }

    Promise.all(resultArr).then(responses => {
        Promise.all(responses).then(json)
    })
}

// const response = await fetch(`${BASE_URL}/discover/tv?api_key=${myApiKey}&with_watch_providers=${8}`);
// const data = await response.json();
// return data;

