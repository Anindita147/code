import Movie from "./Movie";

const TitleList = () => {
    return ( 
    <div className="titleList">
    <div className="title">
      <h1>Results</h1>
      <div className="titles-wrapper"> 
        <Movie/>
      </div>
    </div>
  </div> );
}
 
export default TitleList;