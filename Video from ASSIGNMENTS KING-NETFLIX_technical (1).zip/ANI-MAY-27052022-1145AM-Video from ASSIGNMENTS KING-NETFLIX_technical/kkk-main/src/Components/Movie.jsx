const Movie = () => {
    return ( 
    <div className="movie">
    <a href="details.html"
      ><img src="https://image.tmdb.org/t/p/w500/86TMU2JYnBvd4rnJkEio8ne5teB.jpg" alt="Movie poster" />
      <div className="overlay">
        <div className="title">MasterChef</div>
        <div className="rating">6.8/10</div>
        <div className="plot">
          Danish version of the cooking competition in which celebrity chefs put a group of contestants through a series of challenges and elimination
          rounds, in order to turn one home cook into a culinary master.
        </div>
      </div></a
    >
    <div data-toggled="false" className="listToggle">
      <div><i className="fa fa-fw fa-plus"></i><i className="fa fa-fw fa-check"></i></div>
    </div>
  </div> );
}
 
export default Movie;