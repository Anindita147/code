const ShowDetails = () => {
    return ( 
        <>
        </>
     );
}
 
export default ShowDetails;