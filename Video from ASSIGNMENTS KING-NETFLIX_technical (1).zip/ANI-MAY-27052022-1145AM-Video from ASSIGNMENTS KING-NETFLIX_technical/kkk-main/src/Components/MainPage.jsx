import TitleList from "./TitleList";
const MainPage = () => {
    return ( 
        <>
        <TitleList/>
        </>
        
     );
}
 
export default MainPage;