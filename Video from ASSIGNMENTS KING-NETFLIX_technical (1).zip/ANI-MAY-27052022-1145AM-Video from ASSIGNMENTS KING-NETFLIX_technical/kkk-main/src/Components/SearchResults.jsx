const SearchResults = () => {
    return ( 
        <>
        </>
     );
}
 
export default SearchResults;