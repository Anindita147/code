import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import './App.css';
import { useEffect } from 'react';
import { getMovies } from './services/getApi';
import Header from './Components/Header';
import TitleList from './Components/TitleList';
import MainPage from './Components/MainPage';
import WatchList from './Components/WatchList';
import SearchResults from './Components/SearchResults';
import main from './main';
function App() {

  useEffect(() => {
    getMovies().then(data=>console.log(data));
  }, []);
  return (
    <div className="App">
      <Router>
        <Header/>
        <Routes>
          <Route exact path='/' element={"index.html"}/>
          <Route path='/my-watch-list' element={"my-watch-list.html"}/>
          <Route path='/search' element={<SearchResults/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
